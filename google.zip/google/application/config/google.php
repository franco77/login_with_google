<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['google']['client_id']        = '662870711198-ea7n7oocsom50nkfpn7psbc3jqoe3vi1.apps.googleusercontent.com';
$config['google']['client_secret']    = 'bf59kk8BzEH2OZwAdq_Z9uI7';
$config['google']['redirect_uri']     = 'http://localhost/google/user_authentication/';
$config['google']['application_name'] = '';
$config['google']['api_key']          = '';
$config['google']['scopes']           = array();